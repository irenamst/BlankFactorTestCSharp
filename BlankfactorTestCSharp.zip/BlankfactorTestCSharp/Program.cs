﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlankfactorTestCSharp
{
	internal class Program
	{
		/*
        There is a string "sdfgabcwetrrytruyrtuabcpotre!@#abcprtort" - see above.
        The task is to implement the following method:

        public Dictionary<string,string> processString(String inputStr, String separator);

        The result need to contain the following keys:
        Count : count all substrings (itemstrings)  infront of which there is a separator string 
		(if xxx is the string and A is the separator here: xxxAxxxAxxxAxxx, you need to return 3);
        prefix : if any string exists before the first separator, please provide the text
        sortedItems : a string with all itemstrings concatenated in alphabetical order
        evenChars : a string with concatenated all even indexed chars (2,4,6,8,10th)
		
		notes: 
			1. if there is no separator found in input string then the whole inputString is counted as 1 itemString 
			2. zero length strings should not be includded in count
			3. prefix should not be includded in itemstrings 
			4. prefix schould not be includded in count
			5. itemstrings schould be displayed with space (" ") between each of them in the output
		
		implement all results display inside Main method in following format:
		Count: some number
		Prefix: some string
		sortedItems: some string
		evenChars: some string
		
		Example output when executed with inputString = "abcdefSEPgabcwetSEPsdsSEPdsfgSEPfro",separator = "SEP"));
		
		Count: 4
		Prefix: abcdef
		sortedItems: dsfg fro gabcwet sds
		evenChars: aceSPaceSPdSPsgEfo

        */
		static void Main(string[] args)
		{

			string inputString = "sdfgabcwetrrytruyrtuabcpotre!@#abcprtort";
			var resultList = new List<Dictionary<string, string>>();

			resultList.Add(processString(inputString, "abc"));
			resultList.Add(processString(inputString, "s"));
			resultList.Add(processString(inputString, "r"));
			resultList.Add(processString(inputString, "zi"));
			resultList.Add(processString("abcdefSEPgabcwetSEPsdsSEPdsfgSEPfro", "SEP"));
			Console.WriteLine();

			foreach (var item in resultList)
			{
				foreach(var dic in item)
                {
					Console.WriteLine("{0} {1}",
					dic.Key, dic.Value);
				}
				Console.WriteLine();

			}

		}

		public static Dictionary<string, string> processString(String inputStr, String separator)
		{
			Dictionary<string, string> res = new Dictionary<string, string>();
			string[] separators = { separator };
			string[] splitString= inputStr.Split(separators, StringSplitOptions.None);
			int count = splitString.Length - 1;
			string prefix = splitString[0];
			string[] sortedItems = new string[splitString.Length - 1];
			for (int i = 1; i < splitString.Length; i++)
			{
				sortedItems[i - 1] = splitString[i];
			}
			char[] evenChars = new char[inputStr.Length / 2];
			char[] stringChars = inputStr.ToCharArray();
			for (int i = 1,j=0; i < stringChars.Length; i=i+2,j++)
			{
				evenChars[j]=stringChars[i];
			}
			string sortedItemsConcat = string.Concat(sortedItems);
			string evenCharsString = new string(evenChars);
			res.Add("Count:", count.ToString());
			res.Add("prefix:", prefix);
			res.Add("sortedItems:", sortedItemsConcat);
			res.Add("evenChars:", evenCharsString);
			return res;
		}

	}
}

